import { Component, inject } from '@angular/core';
import { Header } from './components/header/header';
import { GoldPriceCard } from './components/gold-price-card/gold-price-card';
import { GoldCalculator } from './components/gold-calculator/gold-calculator';
import { GoldPriceChart } from './components/gold-price-chart/gold-price-chart';
import { PriceHistory } from './components/price-history/price-history';
import { GoldService } from './services/gold.service';
import { ThemeService } from './services/theme.service';
import { GoldPrice, GoldHistory } from './models/gold.model';

@Component({
  imports: [Header, GoldPriceCard, GoldCalculator, GoldPriceChart, PriceHistory],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {
  private goldService = inject(GoldService);
  themeService = inject(ThemeService);

  goldPrices: GoldPrice[] = this.goldService.getPrices();
  goldHistory: GoldHistory[] = this.goldService.getHistory();

  get isDark() {
    return this.themeService.isDarkMode;
  }

  toggleTheme() {
    this.themeService.toggleTheme();
  }
}
