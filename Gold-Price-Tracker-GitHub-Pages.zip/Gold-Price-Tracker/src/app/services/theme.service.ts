import { Injectable, signal, effect, PLATFORM_ID, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class ThemeService {
  private platformId = inject(PLATFORM_ID);
  
  // 'dark' or 'light'
  isDarkMode = signal<boolean>(true);

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      const savedTheme = localStorage.getItem('gold_theme');
      if (savedTheme) {
        this.isDarkMode.set(savedTheme === 'dark');
      } else {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        this.isDarkMode.set(prefersDark);
      }

      this.applyTheme(this.isDarkMode());

      effect(() => {
        const dark = this.isDarkMode();
        this.applyTheme(dark);
        localStorage.setItem('gold_theme', dark ? 'dark' : 'light');
      });
    }
  }

  toggleTheme() {
    this.isDarkMode.update((current) => !current);
  }

  private applyTheme(dark: boolean) {
    if (isPlatformBrowser(this.platformId)) {
      const root = document.documentElement;
      if (dark) {
        root.classList.add('dark');
        root.classList.remove('light');
      } else {
        root.classList.remove('dark');
        root.classList.add('light');
      }
    }
  }
}
